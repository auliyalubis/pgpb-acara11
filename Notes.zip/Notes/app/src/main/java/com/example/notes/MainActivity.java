package com.example.notes;

import android.os.Bundle;
import android.os.Build;
import android.view.View;
import android.app.DatePickerDialog;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.ListView;
import android.widget.Toast;
import android.widget.DatePicker;

import androidx.appcompat.app.AppCompatActivity;

import com.example.notes.databinding.ActivityMainBinding;

import java.util.ArrayList;
import java.util.Calendar;
import java.util.List;

public class MainActivity extends AppCompatActivity {

    private ActivityMainBinding binding;
    private List<Note> notesList = new ArrayList<>();
    private ArrayAdapter<Note> adapter;
    private Note selectedNote = null;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        binding = ActivityMainBinding.inflate(getLayoutInflater());
        setContentView(binding.getRoot());

        // Initialize ListView and Adapter
        adapter = new ArrayAdapter<>(this, android.R.layout.simple_list_item_1, notesList);
        binding.listView.setAdapter(adapter);

        // Date Picker for EditText edit_date
        binding.editDate.setOnClickListener(view -> showDatePicker());

        // Add Note Button
        binding.btnAdd.setOnClickListener(view -> {
            binding.viewFlipper.setDisplayedChild(1); // Switch to Add/Edit Note Page
            setEmptyField();
        });

        // Submit Button
        binding.btnSubmit.setOnClickListener(view -> {
            if (isFieldValid()) {
                Note note = new Note(
                        binding.editTitle.getText().toString(),
                        binding.editDesc.getText().toString(),
                        binding.editDate.getText().toString()
                );
                notesList.add(note);
                adapter.notifyDataSetChanged();
                binding.viewFlipper.setDisplayedChild(0); // Switch back to Home Page
                Toast.makeText(this, "Note Added", Toast.LENGTH_SHORT).show();
            }
        });

        // ListView Item Click
        binding.listView.setOnItemClickListener((AdapterView<?> adapterView, View view, int position, long id) -> {
            selectedNote = notesList.get(position);
            binding.editTitle.setText(selectedNote.getTitle());
            binding.editDesc.setText(selectedNote.getDescription());
            binding.editDate.setText(selectedNote.getDate());
            binding.viewFlipper.setDisplayedChild(1); // Switch to Add/Edit Note Page
        });

        // Update Button
        binding.btnUpdate.setOnClickListener(view -> {
            if (selectedNote != null && isFieldValid()) {
                selectedNote.setTitle(binding.editTitle.getText().toString());
                selectedNote.setDescription(binding.editDesc.getText().toString());
                selectedNote.setDate(binding.editDate.getText().toString());
                adapter.notifyDataSetChanged();
                binding.viewFlipper.setDisplayedChild(0); // Switch back to Home Page
                Toast.makeText(this, "Note Updated", Toast.LENGTH_SHORT).show();
            }
        });
    }

    private void showDatePicker() {
        // Get the current date
        Calendar calendar = Calendar.getInstance();
        int year = calendar.get(Calendar.YEAR);
        int month = calendar.get(Calendar.MONTH);
        int day = calendar.get(Calendar.DAY_OF_MONTH);

        // Show DatePickerDialog
        DatePickerDialog datePickerDialog = new DatePickerDialog(
                this,
                (DatePicker view, int selectedYear, int selectedMonth, int selectedDay) -> {
                    // Set selected date to the EditText
                    String date = selectedDay + "/" + (selectedMonth + 1) + "/" + selectedYear;
                    binding.editDate.setText(date);
                },
                year, month, day
        );
        datePickerDialog.show();
    }
    private void setEmptyField() {
        binding.editTitle.setText("");
        binding.editDesc.setText("");
        binding.editDate.setText("");
        selectedNote = null;
    }

    private boolean isFieldValid() {
        if (binding.editTitle.getText().toString().isEmpty() ||
                binding.editDesc.getText().toString().isEmpty() ||
                binding.editDate.getText().toString().isEmpty()) {
            Toast.makeText(this, "All fields are required", Toast.LENGTH_SHORT).show();
            return false;
        }
        return true;
    }
}